"""
DocMind -- a small RAG (Retrieval-Augmented Generation) app.

Flow for every question:
  1. Embed the user's question with the same model used for the documents.
  2. Retrieve the top-k most similar chunks from the vector store.
  3. Pass the question + those chunks to an LLM (or, with no API key,
     just show the chunks) so the answer is grounded in your own documents
     instead of the model's general training data.

Run:
    pip install -r requirements.txt
    python app.py
Then open http://localhost:5000
"""

import os
import uuid

from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request

from rag.chunking import chunk_text, extract_text
from rag.generator import generate_answer
from rag.store import VectorStore

load_dotenv()

app = Flask(__name__)
UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

store = VectorStore.load()


@app.route("/")
def index():
    doc_count = len(set(store.sources))
    chunk_count = len(store.chunks)
    return render_template("index.html", doc_count=doc_count, chunk_count=chunk_count)


@app.route("/upload", methods=["POST"])
def upload():
    file = request.files.get("file")
    if not file or file.filename == "":
        return jsonify({"error": "No file selected."}), 400

    if not file.filename.lower().endswith((".txt", ".pdf")):
        return jsonify({"error": "Only .txt and .pdf files are supported."}), 400

    safe_name = f"{uuid.uuid4().hex[:8]}_{file.filename}"
    save_path = os.path.join(UPLOAD_DIR, safe_name)
    file.save(save_path)

    text = extract_text(save_path)
    if not text.strip():
        return jsonify({"error": "Couldn't extract any text from that file."}), 400

    chunks = chunk_text(text)
    store.add(chunks, source=file.filename)
    store.save()

    return jsonify(
        {
            "message": f"Indexed '{file.filename}' into {len(chunks)} chunks.",
            "chunk_count": len(store.chunks),
            "doc_count": len(set(store.sources)),
        }
    )


@app.route("/ask", methods=["POST"])
def ask():
    data = request.get_json(silent=True) or {}
    question = (data.get("question") or "").strip()

    if not question:
        return jsonify({"error": "Please enter a question."}), 400
    if not store.chunks:
        return jsonify({"error": "Upload at least one document first."}), 400

    retrieved = store.search(question, top_k=4)
    answer = generate_answer(question, retrieved)

    return jsonify(
        {
            "answer": answer,
            "sources": [
                {"source": c["source"], "score": round(c["score"], 3), "excerpt": c["text"][:200]}
                for c in retrieved
            ],
        }
    )


@app.route("/reset", methods=["POST"])
def reset():
    store.clear()
    return jsonify({"message": "Cleared all documents."})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
