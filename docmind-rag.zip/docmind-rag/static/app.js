const uploadForm = document.getElementById("upload-form");
const fileInput = document.getElementById("file-input");
const uploadStatus = document.getElementById("upload-status");
const resetBtn = document.getElementById("reset-btn");

const askForm = document.getElementById("ask-form");
const questionInput = document.getElementById("question-input");
const answerArea = document.getElementById("answer-area");
const answerText = document.getElementById("answer-text");
const sourcesList = document.getElementById("sources-list");

uploadForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const file = fileInput.files[0];
  if (!file) return;

  const formData = new FormData();
  formData.append("file", file);

  uploadStatus.textContent = "Indexing…";
  try {
    const res = await fetch("/upload", { method: "POST", body: formData });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Upload failed.");
    uploadStatus.textContent = `${data.message} (${data.doc_count} document(s), ${data.chunk_count} chunks total.)`;
    fileInput.value = "";
  } catch (err) {
    uploadStatus.textContent = `Error: ${err.message}`;
  }
});

resetBtn.addEventListener("click", async () => {
  await fetch("/reset", { method: "POST" });
  uploadStatus.textContent = "No documents indexed yet.";
  answerArea.hidden = true;
});

askForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const question = questionInput.value.trim();
  if (!question) return;

  answerArea.hidden = false;
  answerText.textContent = "Thinking…";
  sourcesList.innerHTML = "";

  try {
    const res = await fetch("/ask", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Something went wrong.");

    answerText.textContent = data.answer;

    sourcesList.innerHTML = "";
    data.sources.forEach((s) => {
      const li = document.createElement("li");
      li.innerHTML = `<span class="src-name">${s.source}</span> <span class="src-score">relevance ${s.score}</span><br/><span class="src-excerpt">"${s.excerpt}…"</span>`;
      sourcesList.appendChild(li);
    });
  } catch (err) {
    answerText.textContent = `Error: ${err.message}`;
  }
});
