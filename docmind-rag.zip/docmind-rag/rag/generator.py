"""
Takes the user's question plus the retrieved chunks and produces a final
answer. This is the "Generation" half of Retrieval-Augmented Generation.

Design choice: DocMind works with EITHER an Anthropic key, an OpenAI key,
or no key at all. With no key, it falls back to "retrieval-only" mode and
just surfaces the most relevant passages directly -- so the whole app is
runnable and demoable without spending any money. This also makes a good
interview talking point: you separated retrieval from generation cleanly
enough that the system degrades gracefully instead of breaking.
"""

import os

ANTHROPIC_KEY = os.getenv("ANTHROPIC_API_KEY")
OPENAI_KEY = os.getenv("OPENAI_API_KEY")

SYSTEM_PROMPT = (
    "You are DocMind, a careful assistant that answers questions using ONLY "
    "the provided document excerpts. If the excerpts don't contain the "
    "answer, say so plainly instead of guessing. Keep answers concise and, "
    "where useful, mention which excerpt you drew from."
)


def _build_context(retrieved_chunks: list[dict]) -> str:
    parts = []
    for i, c in enumerate(retrieved_chunks, start=1):
        parts.append(f"[Excerpt {i} — {c['source']}]\n{c['text']}")
    return "\n\n".join(parts)


def _answer_with_anthropic(question: str, context: str) -> str:
    import anthropic

    client = anthropic.Anthropic(api_key=ANTHROPIC_KEY)
    response = client.messages.create(
        model="claude-3-5-haiku-20241022",
        max_tokens=500,
        system=SYSTEM_PROMPT,
        messages=[
            {
                "role": "user",
                "content": f"Document excerpts:\n\n{context}\n\nQuestion: {question}",
            }
        ],
    )
    return response.content[0].text


def _answer_with_openai(question: str, context: str) -> str:
    from openai import OpenAI

    client = OpenAI(api_key=OPENAI_KEY)
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        max_tokens=500,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {
                "role": "user",
                "content": f"Document excerpts:\n\n{context}\n\nQuestion: {question}",
            },
        ],
    )
    return response.choices[0].message.content


def _answer_retrieval_only(question: str, retrieved_chunks: list[dict]) -> str:
    if not retrieved_chunks:
        return "No relevant passages were found in the uploaded documents."

    lines = [
        "No LLM API key is configured, so here are the most relevant passages "
        "found for your question (retrieval-only mode):\n",
    ]
    for i, c in enumerate(retrieved_chunks, start=1):
        lines.append(f"{i}. ({c['source']}, relevance {c['score']:.2f})\n   \"{c['text'][:220]}...\"")
    return "\n\n".join(lines)


def generate_answer(question: str, retrieved_chunks: list[dict]) -> str:
    context = _build_context(retrieved_chunks)

    if ANTHROPIC_KEY:
        return _answer_with_anthropic(question, context)
    if OPENAI_KEY:
        return _answer_with_openai(question, context)
    return _answer_retrieval_only(question, retrieved_chunks)
