"""
A deliberately simple vector store: embed every chunk once with a local
sentence-transformer model, keep the vectors in memory (and pickled to
disk between runs), and retrieve by cosine similarity.

This is NOT how you'd do RAG at production scale (that's what FAISS,
Pinecone, Weaviate, pgvector etc. are for) -- but understanding this
version first is exactly what lets you talk intelligently about why
those tools exist. In an interview: "I built retrieval with plain numpy
cosine similarity first so I understood what a vector database is
actually optimizing -- then I'd reach for FAISS/pgvector at real scale."
"""

import os
import pickle

import numpy as np

STORE_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "store.pkl")

_model = None


def get_model():
    """Lazily load the embedding model (only once, on first use).

    The import is deliberately inside this function, not at the top of the
    file: sentence-transformers pulls in torch, which is a heavy, slow
    import. Keeping it lazy means `python -m py_compile` and unit tests
    that mock this function never pay that cost.
    """
    global _model
    if _model is None:
        # all-MiniLM-L6-v2: small (~80MB), fast, runs on CPU, good enough
        # quality for a portfolio project. Swap for a larger model later
        # if you want to demonstrate you understand the quality/speed tradeoff.
        from sentence_transformers import SentenceTransformer

        _model = SentenceTransformer("all-MiniLM-L6-v2")
    return _model


class VectorStore:
    def __init__(self):
        self.chunks: list[str] = []
        self.sources: list[str] = []
        self.vectors: np.ndarray | None = None  # shape: (n_chunks, dim)

    def add(self, chunks: list[str], source: str):
        model = get_model()
        new_vectors = model.encode(chunks, normalize_embeddings=True)

        self.chunks.extend(chunks)
        self.sources.extend([source] * len(chunks))

        if self.vectors is None:
            self.vectors = np.array(new_vectors)
        else:
            self.vectors = np.vstack([self.vectors, new_vectors])

    def search(self, query: str, top_k: int = 4):
        if self.vectors is None or len(self.chunks) == 0:
            return []

        model = get_model()
        query_vec = model.encode([query], normalize_embeddings=True)[0]

        # vectors are normalized, so dot product == cosine similarity
        scores = self.vectors @ query_vec
        top_indices = np.argsort(scores)[::-1][:top_k]

        return [
            {
                "text": self.chunks[i],
                "source": self.sources[i],
                "score": float(scores[i]),
            }
            for i in top_indices
        ]

    def save(self):
        os.makedirs(os.path.dirname(STORE_PATH), exist_ok=True)
        with open(STORE_PATH, "wb") as f:
            pickle.dump(
                {"chunks": self.chunks, "sources": self.sources, "vectors": self.vectors},
                f,
            )

    @classmethod
    def load(cls):
        store = cls()
        if os.path.exists(STORE_PATH):
            with open(STORE_PATH, "rb") as f:
                data = pickle.load(f)
            store.chunks = data["chunks"]
            store.sources = data["sources"]
            store.vectors = data["vectors"]
        return store

    def clear(self):
        self.chunks, self.sources, self.vectors = [], [], None
        if os.path.exists(STORE_PATH):
            os.remove(STORE_PATH)
