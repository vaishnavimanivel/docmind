"""
Turns a raw document into overlapping text chunks that are small enough
to embed and retrieve individually, but large enough to carry real meaning.

Why overlap matters: if a sentence that answers the user's question gets
cut in half between two chunks, overlap increases the odds that at least
one chunk contains the full idea.
"""

from pypdf import PdfReader


def extract_text(file_path: str) -> str:
    """Read a .txt or .pdf file and return its raw text."""
    if file_path.lower().endswith(".pdf"):
        reader = PdfReader(file_path)
        pages = [page.extract_text() or "" for page in reader.pages]
        return "\n".join(pages)
    else:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()


def chunk_text(text: str, chunk_size: int = 800, overlap: int = 150) -> list[str]:
    """
    Split text into overlapping chunks of roughly `chunk_size` characters.

    chunk_size=800 / overlap=150 are reasonable defaults for short-to-medium
    documents (a few pages to a few dozen pages). For very long documents,
    a larger chunk_size reduces the total chunk count and speeds up search.
    """
    text = " ".join(text.split())  # normalize whitespace
    if not text:
        return []

    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        chunk = text[start:end]
        chunks.append(chunk)
        if end >= len(text):
            break
        start = end - overlap  # step back by `overlap` so chunks share context

    return chunks
